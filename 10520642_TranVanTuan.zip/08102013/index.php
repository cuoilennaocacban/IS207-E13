<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

    <head>
        <meta charset="utf-8"> 
        <script src="http://code.jquery.com/jquery-latest.min.js"></script>
    </head>

    <body>
        <div>
            <p>08 - 10 - 2013</p>
            <a href="bai1.php">Bài 1</a>
        </div>
        
        <div>
            <p>29 - 10 - 2013</p>
            <a href="MySQL.php">thực hành MySQL</a>
        </div>
        
    </body>
</html>
